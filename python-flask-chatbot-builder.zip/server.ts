import express from "express";
import path from "path";
import { createServer as createViteServer } from "vite";
import { GoogleGenAI } from "@google/genai";
import dotenv from "dotenv";

dotenv.config();

const app = express();
const PORT = 3000;

// Enable JSON body parking with a generous limit
app.use(express.json({ limit: "5mb" }));

// Initialize GenAI client lazily or with a fallback check
const getGenAIClient = () => {
  const apiKey = process.env.GEMINI_API_KEY;
  if (!apiKey || apiKey === "MY_GEMINI_API_KEY" || apiKey.includes("YOUR")) {
    // Return mock indicator or helpful error rather than hard throwing at startup
    console.warn("WARNING: GEMINI_API_KEY is not configured or has default placeholder value.");
  }
  return new GoogleGenAI({
    apiKey: apiKey || "",
    httpOptions: {
      headers: {
        "User-Agent": "aistudio-build",
      },
    },
  });
};

// API Route: Conversation endpoint
app.post("/api/chat", async (req, res) => {
  const { message, history, systemInstruction, temperature } = req.body;

  if (!message) {
    return res.status(400).json({ error: "Message is required" });
  }

  const apiKey = process.env.GEMINI_API_KEY;
  if (!apiKey || apiKey === "MY_GEMINI_API_KEY" || apiKey.trim() === "") {
    return res.status(400).json({ 
      error: "Gemini API Key is missing. Please add your GEMINI_API_KEY under Settings > Secrets to enable live chatbot processing." 
    });
  }

  try {
    const ai = getGenAIClient();
    
    // Format the history items securely for the contents parameter
    const formattedContents = [];
    if (Array.isArray(history)) {
      for (const turn of history) {
        if (turn.text && (turn.role === "user" || turn.role === "model")) {
          formattedContents.push({
            role: turn.role,
            parts: [{ text: turn.text }],
          });
        }
      }
    }

    // Add the current user query to contents
    formattedContents.push({
      role: "user",
      parts: [{ text: message }],
    });

    const config: any = {
      temperature: temperature !== undefined ? Number(temperature) : 0.7,
    };

    if (systemInstruction && systemInstruction.trim() !== "") {
      config.systemInstruction = systemInstruction.trim();
    }

    // Call the free, powerful gemini-3.5-flash model
    const response = await ai.models.generateContent({
      model: "gemini-3.5-flash",
      contents: formattedContents,
      config,
    });

    const reply = response.text || "No response received from the model.";
    res.json({ reply });
  } catch (err: any) {
    console.error("Gemini API Error in /api/chat:", err);
    res.status(500).json({ 
      error: err.message || "An error occurred while communicating with the Gemini generative model." 
    });
  }
});

// Setup Vite Dev Middleware or serve Production Build
async function setupServer() {
  if (process.env.NODE_ENV !== "production") {
    console.log("Setting up Vite in development mode...");
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: "spa",
    });
    app.use(vite.middlewares);
  } else {
    console.log("Setting up static file serving for production...");
    const distPath = path.join(process.cwd(), "dist");
    app.use(express.static(distPath));
    app.get("*", (req, res) => {
      res.sendFile(path.join(distPath, "index.html"));
    });
  }

  app.listen(PORT, "0.0.0.0", () => {
    console.log(`Express server listening on http://0.0.0.0:${PORT}`);
  });
}

setupServer().catch((err) => {
  console.error("Failed to start full-stack server:", err);
});
