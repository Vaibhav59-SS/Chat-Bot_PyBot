import { useState } from "react";
import { ChatSession, FlaskFile } from "./types";
import { FLASK_TEMPLATE_FILES } from "./data/flaskTemplate";
import WorkspaceHeader from "./components/WorkspaceHeader";
import ChatInterface from "./components/ChatInterface";
import { 
  FileCode, Copy, Check, Download, AlertCircle, ChevronRight, 
  Terminal, ShieldCheck, Sparkles, BookOpen, Key, RefreshCw 
} from "lucide-react";

export default function App() {
  const [activeTab, setActiveTab] = useState<"chat" | "code">("chat");
  const [selectedFile, setSelectedFile] = useState<FlaskFile>(FLASK_TEMPLATE_FILES[0]);
  const [copied, setCopied] = useState(false);
  const [copiedAll, setCopiedAll] = useState(false);

  // Maintain interactive NLP conversation session
  const [session, setSession] = useState<ChatSession>({
    id: "default-session",
    name: "Primary NLP Session",
    messages: [],
    systemInstruction: "You are a Python Flask developer assistant. You explain natural language processing concepts using clean definitions, and help construct beautiful chatbot routes.",
    temperature: 0.7,
  });

  // Handle single file copy
  const handleCopyCode = async (content: string) => {
    try {
      await navigator.clipboard.writeText(content);
      setCopied(true);
      setTimeout(() => setCopied(false), 2000);
    } catch (err) {
      console.error("Failed to copy text: ", err);
    }
  };

  // Basic zip builder simulator or trigger multiple downloads
  const handleDownloadFile = (file: FlaskFile) => {
    const element = document.createElement("a");
    const blob = new Blob([file.content], { type: "text/plain" });
    element.href = URL.createObjectURL(blob);
    element.download = file.name;
    document.body.appendChild(element);
    element.click();
    document.body.removeChild(element);
  };

  // Mock download all project files as standard files sequentially
  const handleDownloadAll = () => {
    FLASK_TEMPLATE_FILES.forEach((file, idx) => {
      setTimeout(() => {
        const element = document.createElement("a");
        const blob = new Blob([file.content], { type: "text/plain" });
        element.href = URL.createObjectURL(blob);
        element.download = file.name;
        document.body.appendChild(element);
        element.click();
        document.body.removeChild(element);
      }, idx * 250); // Small stagger to protect tab downloads
    });
    setCopiedAll(true);
    setTimeout(() => setCopiedAll(false), 3000);
  };

  return (
    <div className="bg-slate-900 text-slate-100 min-h-screen flex flex-col font-sans selection:bg-indigo-500/30 selection:text-indigo-200">
      
      {/* Workspace Header Top Navigation */}
      <WorkspaceHeader activeTab={activeTab} setActiveTab={setActiveTab} />

      {/* Main Workspace Frame */}
      <main className="flex-1 max-w-6xl w-full mx-auto p-4 md:p-6 flex flex-col">
        
        {/* TAB 1: Chat Sandbox panel */}
        {activeTab === "chat" && (
          <div className="space-y-4 animate-fade-in">
            {/* Introductory Guide Card */}
            <div className="bg-gradient-to-r from-slate-950 via-indigo-950/20 to-slate-950 border border-slate-800 rounded-2xl p-5 flex flex-col md:flex-row items-start md:items-center justify-between gap-4">
              <div className="space-y-1 max-w-2xl">
                <h2 className="text-sm font-semibold flex items-center gap-2 text-white">
                  <Sparkles className="w-4 h-4 text-indigo-400" />
                  Testing Modern Large Language Model Assistant Locally
                </h2>
                <p className="text-xs text-slate-400 leading-relaxed">
                  Your Python code is configured with natural language processing powered by <strong>Google Gemini 3.5 Flash</strong>. 
                  Below, refine system directives, chat context templates, and test answers before copying files over to your workstation.
                </p>
              </div>
              <button 
                id="view-flask-code-header-btn"
                onClick={() => setActiveTab("code")}
                className="bg-indigo-600/10 hover:bg-indigo-600/20 border border-indigo-500/30 text-indigo-300 font-medium text-xs px-4 py-2 rounded-xl transition duration-150 inline-flex items-center gap-1.5 shrink-0"
              >
                <span>Browse Flask Source</span>
                <ChevronRight className="w-3.5 h-3.5" />
              </button>
            </div>

            {/* Main Interactive Interface Element */}
            <ChatInterface session={session} setSession={setSession} />
          </div>
        )}

        {/* TAB 2: Source Code Template Export Explorer */}
        {activeTab === "code" && (
          <div className="flex-1 flex flex-col lg:flex-row gap-6 animate-fade-in">
            
            {/* Left Hand: Project File System Navigator & Installation Tips */}
            <div className="w-full lg:w-80 shrink-0 space-y-5">
              
              {/* Project File Tree Block */}
              <div className="bg-slate-950 border border-slate-800 rounded-2xl p-5">
                <div className="flex items-center justify-between pb-3 border-b border-slate-800/80 mb-4">
                  <h3 className="text-xs font-semibold uppercase tracking-wider text-slate-400">
                    📂 Project Files Directory
                  </h3>
                  <button
                    onClick={handleDownloadAll}
                    id="download-project-zip-btn"
                    className="text-[10px] bg-indigo-500/10 text-indigo-400 border border-indigo-500/20 px-2 py-1 rounded hover:bg-indigo-500/20 cursor-pointer flex items-center gap-1 transition"
                  >
                    {copiedAll ? <Check className="w-3 h-3 text-emerald-400" /> : <Download className="w-3 h-3" />}
                    <span>{copiedAll ? "Files Downloaded" : "Download All"}</span>
                  </button>
                </div>

                <div className="space-y-1" id="file-directory-list">
                  {FLASK_TEMPLATE_FILES.map((file) => {
                    const isSelected = selectedFile.name === file.name;
                    return (
                      <button
                        key={file.name}
                        onClick={() => setSelectedFile(file)}
                        className={`w-full flex items-center justify-between px-3.5 py-2.5 rounded-xl text-xs font-medium tracking-tight text-left transition ${
                          isSelected
                            ? "bg-indigo-600/10 text-indigo-300 border border-indigo-500/20"
                            : "bg-transparent text-slate-400 hover:text-slate-200 hover:bg-slate-900"
                        }`}
                      >
                        <div className="flex items-center space-x-2.5 min-w-0">
                          <FileCode className={`w-4 h-4 shrink-0 ${isSelected ? "text-indigo-400" : "text-slate-500"}`} />
                          <div className="truncate">
                            <p className="font-mono text-[11px] font-semibold text-slate-200">{file.name}</p>
                            <p className="text-[9.5px] text-slate-500 truncate mt-0.5">{file.path}</p>
                          </div>
                        </div>
                        <ChevronRight className={`w-3.5 h-3.5 shrink-0 ${isSelected ? "text-indigo-400" : "text-slate-600"}`} />
                      </button>
                    );
                  })}
                </div>
              </div>

              {/* Free Google API Key Setup Instruction Guide */}
              <div className="bg-slate-950 border border-slate-800 rounded-2xl p-5 space-y-4">
                <h4 className="text-xs font-semibold uppercase tracking-wider text-slate-400 flex items-center gap-2">
                  <Key className="w-4 h-4 text-emerald-400" />
                  Free Google API Setup
                </h4>
                
                <div className="text-[11.5px] text-slate-400 space-y-3 leading-relaxed">
                  <p>
                    Google developer tools allow developer accounts to operate generative models for free within reasonable rate limits.
                  </p>
                  <ol className="list-decimal pl-4 space-y-2 text-slate-400 font-sans">
                    <li>
                      Visit <a href="https://aistudio.google.com" target="_blank" className="text-indigo-400 underline hover:text-indigo-300">Google AI Studio</a>.
                    </li>
                    <li>
                      Construct a free personal API key with one click.
                    </li>
                    <li>
                      Assign the secret value securely to your environment block inside <strong className="text-slate-200 font-mono text-[10px]">.env</strong> on port 5000:
                      <pre className="mt-1.5 p-2 bg-slate-900 border border-slate-800 rounded text-[10px] text-slate-300 font-mono truncate">
                        GEMINI_API_KEY="AIzaSy..."
                      </pre>
                    </li>
                  </ol>
                </div>
              </div>

            </div>

            {/* Right Hand: Active Selected File Code Preview Area */}
            <div className="flex-1 bg-slate-950 border border-slate-800 rounded-2xl flex flex-col min-w-0">
              
              {/* Code Preview Header */}
              <div className="px-5 py-4 border-b border-slate-800 flex flex-col sm:flex-row sm:items-center justify-between gap-3 bg-slate-950">
                <div>
                  <div className="flex items-center space-x-2">
                    <span className="text-xs font-semibold px-2 py-0.5 rounded bg-slate-900 text-slate-400 font-mono uppercase">
                      {selectedFile.language}
                    </span>
                    <h3 className="text-sm font-semibold tracking-tight text-white font-mono">
                      {selectedFile.name}
                    </h3>
                  </div>
                  <p className="text-[11px] text-slate-400 mt-1">
                    {selectedFile.description}
                  </p>
                </div>

                {/* File Operation Action Items */}
                <div className="flex items-center space-x-2 shrink-0">
                  <button
                    id="copy-to-clipboard-btn"
                    onClick={() => handleCopyCode(selectedFile.content)}
                    className="bg-slate-900 hover:bg-slate-800 border border-slate-800 text-slate-300 text-xs font-medium px-3 py-2 rounded-xl transition duration-150 inline-flex items-center gap-1.5 cursor-pointer"
                  >
                    {copied ? (
                      <>
                        <Check className="w-3.5 h-3.5 text-emerald-400" />
                        <span className="text-emerald-400">Copied!</span>
                      </>
                    ) : (
                      <>
                        <Copy className="w-3.5 h-3.5" />
                        <span>Copy Code</span>
                      </>
                    )}
                  </button>
                  <button
                    id="download-single-file-btn"
                    onClick={() => handleDownloadFile(selectedFile)}
                    className="bg-indigo-600 hover:bg-indigo-500 text-white text-xs font-medium px-3 py-2 rounded-xl transition duration-150 inline-flex items-center gap-1.5 cursor-pointer"
                  >
                    <Download className="w-3.5 h-3.5" />
                    <span>Download</span>
                  </button>
                </div>
              </div>

              {/* Code Display pre format */}
              <div className="flex-1 overflow-auto bg-slate-950 p-5 font-mono text-[11px] leading-relaxed relative">
                <pre className="text-slate-200 whitespace-pre overflow-x-auto select-text selection:bg-indigo-500/40">
                  <code>{selectedFile.content}</code>
                </pre>
              </div>

            </div>

          </div>
        )}

      </main>

      {/* Workspace Footer Margins */}
      <footer className="border-t border-slate-800/60 bg-slate-950 py-4 px-6 text-center text-xs text-slate-500 mt-auto leading-normal">
        <div className="max-w-6xl mx-auto flex flex-col md:flex-row items-center justify-between gap-2.5">
          <p>
            Python Flask NLP Chatbot • Styled with Tailwind CSS & Lucide Icons
          </p>
          <p>
            Uses official GenAI client <code className="text-[10px] bg-slate-900 py-0.5 px-1.5 rounded text-indigo-400 border border-slate-800">google-genai</code> SDK configuration
          </p>
        </div>
      </footer>

    </div>
  );
}
