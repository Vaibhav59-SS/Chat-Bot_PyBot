export interface Message {
  id: string;
  role: "user" | "model" | "system";
  text: string;
  timestamp: Date;
}

export interface ChatSession {
  id: string;
  name: string;
  messages: Message[];
  systemInstruction: string;
  temperature: number;
}

export interface FlaskFile {
  name: string;
  path: string;
  language: "python" | "html" | "txt" | "markdown" | "env";
  content: string;
  description: string;
}
