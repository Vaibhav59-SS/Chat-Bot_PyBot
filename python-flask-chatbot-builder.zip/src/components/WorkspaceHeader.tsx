import { MessageSquare, Code, Terminal, ExternalLink } from "lucide-react";

interface WorkspaceHeaderProps {
  activeTab: "chat" | "code";
  setActiveTab: (tab: "chat" | "code") => void;
}

export default function WorkspaceHeader({ activeTab, setActiveTab }: WorkspaceHeaderProps) {
  return (
    <header className="border-b border-slate-800 bg-slate-900/60 backdrop-blur sticky top-0 z-50 px-6 py-4">
      <div className="max-w-6xl mx-auto flex flex-col sm:flex-row items-center justify-between gap-4">
        
        {/* Brand Identity */}
        <div className="flex items-center space-x-3">
          <div className="relative flex items-center justify-center w-10 h-10 rounded-xl bg-gradient-to-tr from-emerald-500/20 via-sky-500/10 to-indigo-500/20 border border-slate-700/80 shadow-md">
            <span className="text-xl">🐍</span>
            <div className="absolute -top-1 -right-1 w-3 h-3 bg-indigo-500 rounded-full border-2 border-slate-900"></div>
          </div>
          <div>
            <h1 className="text-md font-semibold tracking-tight text-slate-100 flex items-center gap-1.5">
              Python Flask Chatbot Hub
              <span className="text-[10px] uppercase bg-emerald-500/10 text-emerald-400 border border-emerald-500/20 px-2 py-0.5 rounded font-mono font-medium">Free API API</span>
            </h1>
            <p className="text-xs text-slate-400">Build local Python NLP bots with conversational AI</p>
          </div>
        </div>

        {/* Tab Selector & Actions */}
        <div className="flex items-center space-x-2">
          {/* Action Tabs */}
          <div className="bg-slate-950 border border-slate-800 rounded-lg p-1 flex">
            <button
              id="tab-chat-btn"
              onClick={() => setActiveTab("chat")}
              className={`flex items-center space-x-1.5 px-4 py-1.5 rounded-md text-xs font-medium transition-all ${
                activeTab === "chat"
                  ? "bg-indigo-600 text-white shadow"
                  : "text-slate-400 hover:text-slate-200"
              }`}
            >
              <MessageSquare className="w-3.5 h-3.5" />
              <span>Interactive NLP Sandbox</span>
            </button>
            <button
              id="tab-code-btn"
              onClick={() => setActiveTab("code")}
              className={`flex items-center space-x-1.5 px-4 py-1.5 rounded-md text-xs font-medium transition-all ${
                activeTab === "code"
                  ? "bg-indigo-600 text-white shadow"
                  : "text-slate-400 hover:text-slate-200"
              }`}
            >
              <Code className="w-3.5 h-3.5" />
              <span>Flask Source Export</span>
            </button>
          </div>

          {/* Quick link button to official docs for developer reference */}
          <a
            href="https://aistudio.google.com"
            target="_blank"
            referrerPolicy="no-referrer"
            className="hidden md:flex items-center space-x-1 px-3 py-1.5 text-xs text-indigo-400 hover:text-indigo-300 transition"
          >
            <span className="font-mono">Google AI Studio</span>
            <ExternalLink className="w-3 h-3" />
          </a>
        </div>

      </div>
    </header>
  );
}
