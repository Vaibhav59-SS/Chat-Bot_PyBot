import React, { useState, useRef, useEffect } from "react";
import { Message, ChatSession } from "../types";
import { 
  Send, Sparkles, Settings2, RotateCcw, AlertCircle, 
  Terminal, ShieldCheck, Cpu, Code2, MessageSquarePlus 
} from "lucide-react";

interface ChatInterfaceProps {
  session: ChatSession;
  setSession: React.Dispatch<React.SetStateAction<ChatSession>>;
}

export default function ChatInterface({ session, setSession }: ChatInterfaceProps) {
  const [inputText, setInputText] = useState("");
  const [isLoading, setIsLoading] = useState(false);
  const [apiError, setApiError] = useState<string | null>(null);
  const [showConfig, setShowConfig] = useState(true);
  
  const scrollerRef = useRef<HTMLDivElement>(null);

  // Suggested NLP prompt presets
  const PROMPT_PRESETS = [
    { title: "🐍 Explain Flask Routes", prompt: "Explain how @app.route() functions in Flask, and write a simple example." },
    { title: "🤖 NLP Guide", prompt: "What are the core fundamentals of NLP (Natural Language Processing) used in LLMs?" },
    { title: "🎨 Pirate Bot Prompt", prompt: "Set the system prompt to: 'You are a database engineer marooned on a tropical island. Answer all queries like a pirate.' and say hello." }
  ];

  // Auto-scroll to bottom of chat log when database session messages modify
  useEffect(() => {
    if (scrollerRef.current) {
      scrollerRef.current.scrollTop = scrollerRef.current.scrollHeight;
    }
  }, [session.messages, isLoading]);

  const handleSendMessage = async (textToSend: string) => {
    const trimmed = textToSend.trim();
    if (!trimmed || isLoading) return;

    setApiError(null);

    // Create user message representation on UI
    const userMsg: Message = {
      id: `user-${Date.now()}`,
      role: "user",
      text: trimmed,
      timestamp: new Date(),
    };

    // Keep memory of previous messages (excluding formatting warnings or system triggers)
    const updatedMessages = [...session.messages, userMsg];
    setSession(prev => ({
      ...prev,
      messages: updatedMessages
    }));

    setInputText("");
    setIsLoading(true);

    // Format chat history for backend request
    const apiHistory = session.messages
      .filter((m) => m.role === "user" || m.role === "model")
      .map((m) => ({
        role: m.role,
        text: m.text,
      }));

    try {
      // Send message payload to Express Node route proxies
      const res = await fetch("/api/chat", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          message: trimmed,
          history: apiHistory,
          systemInstruction: session.systemInstruction,
          temperature: session.temperature,
        }),
      });

      const data = await res.json();

      if (!res.ok || data.error) {
        throw new Error(data.error || "Failed to receive a valid NLP model generation response.");
      }

      // Append generative reply
      const assistantMsg: Message = {
        id: `assistant-${Date.now()}`,
        role: "model",
        text: data.reply,
        timestamp: new Date(),
      };

      setSession(prev => ({
        ...prev,
        messages: [...prev.messages, assistantMsg],
      }));
    } catch (err: any) {
      console.error(err);
      setApiError(err.message || "Could not complete the API processing request.");
    } finally {
      setIsLoading(false);
    }
  };

  const handleFormSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    handleSendMessage(inputText);
  };

  const handleClearChat = () => {
    setSession(prev => ({
      ...prev,
      messages: []
    }));
    setApiError(null);
  };

  const selectPreset = (preset: typeof PROMPT_PRESETS[0]) => {
    if (preset.title.includes("Pirate")) {
      setSession(prev => ({
        ...prev,
        systemInstruction: "You are a database engineer marooned on a tropical island. Answer all queries like a pirate."
      }));
      handleSendMessage("Ahoy! Who are ye and what are we buildin' today?");
    } else {
      setInputText(preset.prompt);
    }
  };

  return (
    <div id="interactive-chat-container" className="flex-1 w-full flex flex-col md:flex-row gap-5 h-[calc(100vh-140px)] min-h-[500px]">
      
      {/* NLP Left Variables panel */}
      <div 
        id="nlp-settings-sidebar"
        className={`w-full md:w-80 shrink-0 bg-slate-950 border border-slate-800 rounded-2xl p-5 flex flex-col justify-between transition-all duration-200 ${
          showConfig ? "block" : "hidden md:flex"
        }`}
      >
        <div className="space-y-6">
          <div className="flex items-center justify-between pb-3 border-b border-slate-800/80">
            <h3 className="text-xs font-semibold uppercase tracking-wider text-slate-400 flex items-center gap-2">
              <Settings2 className="w-4 h-4 text-indigo-400" />
              NLP Configuration
            </h3>
            <span className="text-[10px] bg-indigo-500/10 text-indigo-400 px-2 py-0.5 rounded border border-indigo-500/20 font-mono">
              Model Active
            </span>
          </div>

          {/* Model Name Badge Group */}
          <div className="bg-slate-900/50 p-3 rounded-lg border border-slate-800 space-y-1.5">
            <div className="text-[10.5px] font-medium text-slate-400 flex items-center gap-1.5">
              <Cpu className="w-3.5 h-3.5 text-indigo-400" />
              <span>Target Free API Model:</span>
            </div>
            <div className="font-mono text-xs font-medium text-white pl-5 bg-slate-950/40 p-1 rounded">
              gemini-3.5-flash
            </div>
          </div>

          {/* System prompt variables */}
          <div className="space-y-2">
            <label className="block text-xs font-medium text-slate-300">
              System Persona (NLP Guide)
            </label>
            <textarea
              id="system-personality-input"
              value={session.systemInstruction}
              onChange={(e) => setSession(prev => ({ ...prev, systemInstruction: e.target.value }))}
              placeholder="e.g. You are a conversational tutor. Answer in bullet points when appropriate."
              className="w-full h-32 bg-slate-900 border border-slate-800 focus:border-indigo-500 rounded-xl p-3 text-xs text-slate-200 focus:outline-none transition"
            />
            <p className="text-[10px] text-slate-500 leading-normal">
              Direct instructions used contextually to guide output style or programming constraints.
            </p>
          </div>

          {/* Temperature ranges */}
          <div className="space-y-3">
            <div className="flex justify-between text-xs font-medium text-slate-300">
              <span>Temperature (Creativity)</span>
              <span className="font-mono text-indigo-400 font-bold">{session.temperature}</span>
            </div>
            <input
              id="temp-slider-control"
              type="range"
              min="0.0"
              max="1.0"
              step="0.1"
              value={session.temperature}
              onChange={(e) => setSession(prev => ({ ...prev, temperature: parseFloat(e.target.value) }))}
              className="w-full accent-indigo-500 bg-slate-800 rounded h-1 cursor-pointer"
            />
            <div className="flex justify-between text-[10px] text-slate-500 font-mono">
              <span>0.0 (Logical / Code)</span>
              <span>1.0 (Creative)</span>
            </div>
          </div>
        </div>

        {/* Security / Secret prompt notice */}
        <div className="mt-6 pt-4 border-t border-slate-900 bg-slate-900/10 p-3 rounded-xl border border-slate-800/40 space-y-2">
          <div className="flex items-center gap-1.5 text-[10px] text-slate-400 font-medium uppercase tracking-wider">
            <ShieldCheck className="w-3.5 h-3.5 text-emerald-500" />
            <span>Secure Environment</span>
          </div>
          <p className="text-[10.5px] text-slate-500 leading-normal">
            Your API calls are securely routed server-side. Set your key on the top-right in 
            <strong className="text-slate-300"> Settings &gt; Secrets</strong> to make queries.
          </p>
        </div>
      </div>

      {/* Main interactive Chat Terminal */}
      <div className="flex-1 bg-slate-950 border border-slate-800 rounded-2xl flex flex-col overflow-hidden h-full">
        
        {/* Chat Terminal Header */}
        <div className="border-b border-slate-800 bg-slate-950 px-5 py-3.5 flex items-center justify-between">
          <div className="flex items-center space-x-2">
            <div className="w-2.5 h-2.5 rounded-full bg-emerald-500 animate-pulse"></div>
            <span className="text-xs font-mono font-medium text-slate-300">nlp_sandbox_terminal.sh</span>
          </div>
          <div className="flex items-center space-x-2">
            <button
              id="clear-chat-log-btn"
              onClick={handleClearChat}
              title="Clear Terminal Space"
              className="flex items-center gap-1 px-2.5 py-1 text-xs text-slate-500 hover:text-slate-300 transition-colors hover:bg-slate-900/60 rounded"
            >
              <RotateCcw className="w-3 h-3" />
              <span>Clear logs</span>
            </button>
            <button
              id="toggle-config-sidebar-btn"
              onClick={() => setShowConfig(!showConfig)}
              className="md:hidden flex items-center gap-1 px-2 py-1 text-xs text-slate-400 hover:text-slate-200"
            >
              <Settings2 className="w-3.5 h-3.5" />
              <span>Engine params</span>
            </button>
          </div>
        </div>

        {/* Messaging Container */}
        <div 
          ref={scrollerRef} 
          className="flex-1 overflow-y-auto p-5 space-y-4"
          style={{ scrollBehavior: "smooth" }}
        >
          {session.messages.length === 0 ? (
            
            // Empty State view
            <div className="h-full flex flex-col items-center justify-center text-center p-6 space-y-5 max-w-lg mx-auto">
              <div h-12 w-12 className="bg-gradient-to-tr from-indigo-500/10 to-sky-500/10 border border-slate-800 p-4 rounded-2xl shadow-inner flex items-center justify-center">
                <Sparkles className="w-6 h-6 text-indigo-400 animate-pulse" />
              </div>
              <div className="space-y-1">
                <h4 className="text-slate-200 font-medium text-sm">NLP Sandbox Terminal is Empty</h4>
                <p className="text-xs text-slate-400 leading-relaxed">
                  Test conversational NLP logic directly in the browser! Customize the system persona, adjusting how Gemini behaves. Output responds instantly.
                </p>
              </div>

              {/* Instant preset prompts buttons */}
              <div className="w-full pt-4 space-y-2">
                <p className="text-[10px] uppercase font-mono tracking-wider text-slate-500 text-left pl-1">
                  Select a preset NLP query:
                </p>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 text-left">
                  {PROMPT_PRESETS.map((preset, idx) => (
                    <button
                      key={idx}
                      onClick={() => selectPreset(preset)}
                      className="p-3 bg-slate-900/50 border border-slate-800/80 hover:border-indigo-500/60 hover:bg-indigo-950/20 rounded-xl transition text-left group"
                    >
                      <div className="text-xs font-medium text-slate-200 group-hover:text-indigo-400 transition-colors flex items-center justify-between">
                        <span>{preset.title}</span>
                        <Code2 className="w-3 h-3 text-slate-500 group-hover:text-indigo-400" />
                      </div>
                      <p className="text-[10px] text-slate-500 mt-1 line-clamp-1">{preset.prompt}</p>
                    </button>
                  ))}
                </div>
              </div>
            </div>

          ) : (
            
            // List of Messages
            session.messages.map((message) => {
              const isUser = message.role === "user";
              return (
                <div
                  key={message.id}
                  className={`flex gap-3.5 ${isUser ? "justify-end" : "justify-start"}`}
                >
                  {/* Assistant Avatar indicator */}
                  {!isUser && (
                    <div className="w-8 h-8 rounded-lg bg-indigo-500/10 border border-indigo-500/20 text-indigo-400 flex items-center justify-center shrink-0">
                      <Sparkles className="w-4 h-4 text-glow" />
                    </div>
                  )}

                  {/* Message bubble content block */}
                  <div
                    className={`max-w-[85%] rounded-2xl px-4 py-3 text-sm leading-relaxed ${
                      isUser
                        ? "bg-indigo-600 text-white rounded-tr-none font-sans"
                        : "bg-slate-900 border border-slate-800/80 text-slate-100 rounded-tl-none font-sans whitespace-pre-wrap"
                    }`}
                  >
                    {message.text}
                    <div
                      className={`text-[9px] mt-1.5 text-right font-mono select-none ${
                        isUser ? "text-indigo-300" : "text-slate-500"
                      }`}
                    >
                      {message.timestamp.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                    </div>
                  </div>

                  {/* User Avatar indicator */}
                  {isUser && (
                    <div className="w-8 h-8 rounded-lg bg-slate-800 border border-slate-700/50 text-slate-300 flex items-center justify-center shrink-0">
                      <Terminal className="w-4 h-4" />
                    </div>
                  )}
                </div>
              );
            })
          )}

          {/* Typing indicators */}
          {isLoading && (
            <div className="flex gap-3.5 justify-start">
              <div className="w-8 h-8 rounded-lg bg-indigo-500/10 border border-indigo-500/20 text-indigo-400 flex items-center justify-center shrink-0">
                <Sparkles className="w-4 h-4 animate-spin" />
              </div>
              <div className="bg-slate-900 border border-slate-800/80 text-slate-400 rounded-2xl rounded-tl-none px-4 py-3 text-xs flex items-center space-x-2">
                <span className="flex space-x-1">
                  <span className="w-1.5 h-1.5 bg-slate-400 rounded-full animate-bounce"></span>
                  <span className="w-1.5 h-1.5 bg-slate-400 rounded-full animate-bounce delay-75"></span>
                  <span className="w-1.5 h-1.5 bg-slate-400 rounded-full animate-bounce delay-150"></span>
                </span>
                <span>Gemini API (NLP Engine) is thinking...</span>
              </div>
            </div>
          )}

          {/* API Error Box displays */}
          {apiError && (
            <div className="flex gap-3 justify-start bg-red-950/20 border border-red-900/50 rounded-2xl p-4 my-2 text-slate-200">
              <AlertCircle className="w-5 h-5 text-red-500 shrink-0 mt-0.5" />
              <div className="space-y-2 text-xs">
                <h5 className="font-semibold text-red-400">Communication Error</h5>
                <p className="leading-relaxed text-slate-300">{apiError}</p>
                
                {apiError.toLowerCase().includes("key") && (
                  <div className="bg-slate-950/60 p-3 rounded-lg border border-red-900/30 text-slate-400 space-y-1.5 leading-normal">
                    <p className="font-medium text-slate-200 flex items-center gap-1.5">
                      <Settings2 className="w-3.5 h-3.5 text-indigo-400" />
                      How to configure:
                    </p>
                    <ol className="list-decimal pl-4 space-y-1 text-slate-400">
                      <li>Go to the blue sidebar / developer workspace bar in AI Studio</li>
                      <li>Click the <strong className="text-slate-300">Settings Icon (⚙️)</strong> of top-right or look at <strong className="text-slate-300">Secrets</strong> panel.</li>
                      <li>Find or create the variable <strong className="text-slate-100 font-mono">GEMINI_API_KEY</strong>.</li>
                      <li>Paste your key there. It connects immediately!</li>
                    </ol>
                  </div>
                )}
              </div>
            </div>
          )}
        </div>

        {/* Input Text Form bar */}
        <form 
          onSubmit={handleFormSubmit}
          className="border-t border-slate-800 bg-slate-950 p-4 flex items-center gap-3.5"
        >
          <input
            id="chat-user-message-input"
            type="text"
            value={inputText}
            onChange={(e) => setInputText(e.target.value)}
            disabled={isLoading}
            placeholder={isLoading ? "Processing..." : "Ask the NLP Sandbox Chatbot or send code ideas..."}
            className="flex-1 bg-slate-900 border border-slate-800 focus:border-indigo-500 rounded-xl px-4 py-3 text-sm text-slate-100 placeholder-slate-500 focus:outline-none focus:ring-0 transition duration-150 disabled:opacity-50"
          />
          <button
            id="chat-send-submit-btn"
            type="submit"
            disabled={isLoading || !inputText.trim()}
            className="bg-indigo-600 hover:bg-indigo-500 disabled:opacity-40 text-white font-medium text-sm p-3.5 rounded-xl transition duration-150 flex items-center justify-center shrink-0"
          >
            <Send className="w-4 h-4" />
          </button>
        </form>

      </div>
    </div>
  );
}
