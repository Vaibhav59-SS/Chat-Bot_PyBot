import { FlaskFile } from "../types";

export const FLASK_TEMPLATE_FILES: FlaskFile[] = [
  {
    name: "app.py",
    path: "app.py",
    language: "python",
    description: "The core Flask backend application handling NLP routing and Google Gemini API communication.",
    content: `import os
from flask import Flask, render_template, request, jsonify
from google import genai
from google.genai import types
from dotenv import load_dotenv

# Load local environment variables from .env file
load_dotenv()

app = Flask(__name__)

# Initialize the modern Google GenAI Client
# It automatically reads GEMINI_API_KEY from environment variables
api_key = os.getenv("GEMINI_API_KEY")
if not api_key:
    print("⚠️ WARNING: GEMINI_API_KEY environment variable is not set!")
    print("   Please create a .env file containing: GEMINI_API_KEY=your_key")

client = genai.Client()

@app.route("/")
def index():
    """Renders the interactive web chat interface."""
    return render_template("index.html")

@app.route("/api/chat", methods=["POST"])
def chat():
    """
    NLP API route to process conversation history and call Gemini.
    Expects JSON request with 'message', 'history', 'system_instruction', and 'temperature'.
    """
    try:
        data = request.json or {}
        user_message = data.get("message", "").strip()
        history = data.get("history", [])
        system_instruction = data.get("system_instruction", "").strip()
        temperature = float(data.get("temperature", 0.7))

        if not user_message:
            return jsonify({"error": "Message is required"}), 400

        # Build contents array keeping conversational context
        # Convert incoming chat history to standard Google GenAI format
        contents = []
        for turn in history:
            role = "user" if turn.get("role") == "user" else "model"
            contents.append(
                types.Content(
                    role=role,
                    parts=[types.Part.from_text(text=turn.get("text", ""))]
                )
            )

        # Append the new user message as the final turn
        contents.append(
            types.Content(
                role="user",
                parts=[types.Part.from_text(text=user_message)]
            )
        )

        # Build execution configuration
        config = types.GenerateContentConfig(
            temperature=temperature
        )
        
        if system_instruction:
            config.system_instruction = system_instruction

        # Call Gemini 3.5 Flash (Free-tier friendly, lightning-fast NLP model)
        response = client.models.generate_content(
            model="gemini-3.5-flash",
            contents=contents,
            config=config
        )

        reply = response.text or "No reply could be generated."
        return jsonify({"reply": reply})

    except Exception as e:
        print(f"❌ Error processing chat: {e}")
        return jsonify({"error": str(e)}), 500

if __name__ == "__main__":
    print("⚡ Starting Python Flask NLP Chatbot on http://127.0.0.1:5000")
    # Run locally with interactive debug enabled
    app.run(debug=True, port=5000)
`
  },
  {
    name: "index.html",
    path: "templates/index.html",
    language: "html",
    description: "The frontend interface styled with Tailwind CSS, supporting local Markdown rendering, custom styles, and scroll features.",
    content: `<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Flask NLP Chatbot</title>
    <!-- Tailwind CSS Script -->
    <script src="https://cdn.tailwindcss.com"></script>
    <!-- Marked Markdown Parser (For rendering conversational tables, bullets, and bold text) -->
    <script src="https://cdn.jsdelivr.net/npm/marked/marked.min.js"></script>
    <style>
        /* Custom styled scrollbars */
        ::-webkit-scrollbar {
            width: 6px;
        }
        ::-webkit-scrollbar-track {
            background: #1e293b;
        }
        ::-webkit-scrollbar-thumb {
            background: #475569;
            border-radius: 3px;
        }
        ::-webkit-scrollbar-thumb:hover {
            background: #64748b;
        }
    </style>
</head>
<body class="bg-slate-900 text-slate-100 flex flex-col min-h-screen">

    <!-- Header -->
    <header class="border-b border-slate-800 bg-slate-900/80 backdrop-blur px-6 py-4 sticky top-0 z-50">
        <div class="max-w-4xl mx-auto flex items-center justify-between">
            <div class="flex items-center space-x-3">
                <span class="text-2xl">🐍</span>
                <div>
                    <h1 class="text-lg font-semibold tracking-tight text-white leading-none">PyFlask Assistant</h1>
                    <p class="text-xs text-slate-400 mt-1">Local NLP Chatbot Sandbox</p>
                </div>
            </div>
            <div class="flex items-center space-x-2">
                <span class="w-2.5 h-2.5 rounded-full bg-emerald-500 animate-pulse"></span>
                <span class="text-xs font-mono text-slate-300">Server Running (5000)</span>
            </div>
        </div>
    </header>

    <!-- Main Container -->
    <main class="flex-1 w-full max-w-4xl mx-auto p-4 flex flex-col md:flex-row gap-4 h-[calc(100vh-140px)]">
        
        <!-- NLP Config Sidebar (Optional variables) -->
        <div class="w-full md:w-64 bg-slate-950 border border-slate-800 rounded-xl p-4 flex flex-col justify-between shrink-0">
            <div>
                <h3 class="text-sm font-semibold uppercase tracking-wider text-slate-400 mb-4 flex items-center">
                    ⚙️ NLP Engine Config
                </h3>
                
                <!-- System Instruction Input -->
                <div class="mb-4">
                    <label class="block text-xs font-medium text-slate-400 mb-1" for="system-instruction">
                        System Prompt (Personality)
                    </label>
                    <textarea id="system-instruction" 
                        class="w-full h-24 text-xs bg-slate-900 border border-slate-800 rounded-lg p-2 text-slate-200 focus:outline-none focus:border-indigo-500"
                        placeholder="e.g. You are a helpful Python assistant. Speak in short replies."></textarea>
                </div>

                <!-- Temperature Input -->
                <div class="mb-2">
                    <div class="flex justify-between text-xs font-medium text-slate-400 mb-1">
                        <span>Temperature (Creativity)</span>
                        <span id="temp-val" class="font-mono text-indigo-400">0.7</span>
                    </div>
                    <input type="range" id="temperature" min="0.0" max="1.0" step="0.1" value="0.7" 
                        class="w-full accent-indigo-500 bg-slate-800 rounded"
                        oninput="document.getElementById('temp-val').innerText = this.value">
                </div>
            </div>

            <div class="text-[10px] text-slate-500 text-center leading-relaxed mt-4 pt-2 border-t border-slate-800/50">
                Powered by Python, Flask, and the Google Gemini-3.5-Flash API
            </div>
        </div>

        <!-- Chat Container -->
        <div class="flex-1 bg-slate-950 border border-slate-800 rounded-xl flex flex-col overflow-hidden h-full">
            
            <!-- Chat Logs -->
            <div id="chat-scroller" class="flex-1 overflow-y-auto p-4 space-y-4">
                
                <!-- Welcome greeting -->
                <div class="flex items-start gap-3">
                    <div class="w-8 h-8 rounded-full bg-emerald-500/10 border border-emerald-500/20 flex items-center justify-center text-sm shrink-0">🤖</div>
                    <div class="bg-slate-900/60 p-3 rounded-2xl rounded-tl-none max-w-[85%] border border-slate-800/40 text-slate-200">
                        <p class="text-sm">Hello! I am your locally-hosted NLP flask chatbot. Ask me anything, or instruct my personality in the sidebar.</p>
                    </div>
                </div>

            </div>

            <!-- Typing indicator -->
            <div id="typing-indicator" class="hidden px-4 py-2 text-xs text-slate-400 flex items-center space-x-2 bg-slate-900/20 border-t border-slate-800/30">
                <span class="animate-bounce">●</span><span class="animate-bounce delay-100">●</span><span class="animate-bounce delay-200">●</span>
                <span>AI NLP system is processing...</span>
            </div>

            <!-- Input area -->
            <form id="chat-form" class="p-3 bg-slate-900 border-t border-slate-800/80 flex items-center gap-2">
                <input type="text" id="user-input" required autocomplete="off"
                    class="flex-1 bg-slate-950 border border-slate-800 rounded-xl px-4 py-3 text-sm text-slate-100 placeholder-slate-500 focus:outline-none focus:border-indigo-500"
                    placeholder="Ask Python assistant...">
                <button type="submit" 
                    class="bg-indigo-600 hover:bg-indigo-500 text-white font-medium text-sm px-5 py-3 rounded-xl transition duration-150 flex items-center gap-1.5 shrink-0">
                    <span>Send</span>
                    <span class="text-xs">🚀</span>
                </button>
            </form>

        </div>
    </main>

    <!-- Javascript Logic -->
    <script>
        const chatForm = document.getElementById("chat-form");
        const userInput = document.getElementById("user-input");
        const chatScroller = document.getElementById("chat-scroller");
        const typingIndicator = document.getElementById("typing-indicator");
        
        // Conversational state storage
        const history = [];

        // Utility to scroll container down
        function scrollToBottom() {
            chatScroller.scrollTop = chatScroller.scrollHeight;
        }

        // Add message log element to the scroller
        function appendMessage(role, text) {
            const isUser = role === "user";
            const wrapper = document.createElement("div");
            wrapper.className = \`flex items-start gap-3 \${isUser ? 'justify-end' : ''}\`;

            // HTML components
            const avatar = isUser 
                ? '<div class="w-8 h-8 rounded-full bg-indigo-500/10 border border-indigo-500/20 flex items-center justify-center text-sm shrink-0">👤</div>' 
                : '<div class="w-8 h-8 rounded-full bg-emerald-500/10 border border-emerald-500/20 flex items-center justify-center text-sm shrink-0">🤖</div>';

            const balloon = \`
                <div class="\${isUser ? 'bg-indigo-600/90 border border-indigo-500/30 rounded-tr-none' : 'bg-slate-900/65 border border-slate-800 rounded-tl-none'} p-3 rounded-2xl max-w-[85%] text-slate-100 text-sm prose prose-invert">
                    \${isUser ? text : marked.parse(text)}
                </div>
            \`;

            wrapper.innerHTML = isUser ? (balloon + avatar) : (avatar + balloon);
            chatScroller.appendChild(wrapper);
            scrollToBottom();
        }

        chatForm.addEventListener("submit", async (e) => {
            e.preventDefault();
            const text = userInput.value.trim();
            if (!text) return;

            // Clear input field immediately
            userInput.value = "";

            // Render message on UI
            appendMessage("user", text);

            // Display typing spinner
            typingIndicator.classList.remove("hidden");
            scrollToBottom();

            const system_instruction = document.getElementById("system-instruction").value.trim();
            const temperature = parseFloat(document.getElementById("temperature").value);

            try {
                // Submit chat history & prompt to Flask API
                const response = await fetch("/api/chat", {
                    method: "POST",
                    headers: {
                        "Content-Type": "application/json"
                    },
                    body: JSON.stringify({
                        message: text,
                        history: history,
                        system_instruction: system_instruction,
                        temperature: temperature
                    })
                });

                const data = await response.json();
                
                typingIndicator.classList.add("hidden");

                if (data.reply) {
                    appendMessage("model", data.reply);
                    
                    // Push context items to local model history
                    history.push({role: "user", text: text});
                    history.push({role: "model", text: data.reply});
                } else if (data.error) {
                    appendMessage("model", "⚠️ **Flask Backend Error:** " + data.error);
                }
            } catch (err) {
                typingIndicator.classList.add("hidden");
                appendMessage("model", "⚠️ **Network Error:** Could not connect to Flask API. Please verify server app.py is alive on port 5000.");
            }
        });
    </script>
</body>
</html>
`
  },
  {
    name: "requirements.txt",
    path: "requirements.txt",
    language: "txt",
    description: "Declares required dependencies to pull down via pip before firing up Python Flask.",
    content: `flask>=3.0.2
google-genai>=0.2.2
python-dotenv>=1.0.1
`
  },
  {
    name: ".env.example",
    path: ".env.example",
    language: "env",
    description: "Example environmental variables file. Set your API Key here to run the Google API freely.",
    content: `# Get a free Gemini API key from https://aistudio.google.com/
GEMINI_API_KEY="YOUR_GOOGLE_FREE_API_KEY_HERE"
`
  },
  {
    name: "README.md",
    path: "README.md",
    language: "markdown",
    description: "Step-by-step setup guides to launch your local Python Flask AI Chatbot server program successfully.",
    content: `# 🐍 Python Flask NLP Chatbot with Google Gemini API

A beautiful, lightweight, and fully responsive chat application using Python, Flask, and the modern **Google GenAI Python SDK** allowing full NLP conversational control.

## 🚀 Easy 5-Minute Setup

### Prerequisites
Make sure you have **Python 3.9+** installed on your workstation. Verify with:
\`\`\`bash
python --version
\`\`\`

---

### Step 1: Download or Unpack project files
Keep this hierarchy on your machine:
\`\`\`
├── app.py
├── requirements.txt
├── .env.example
├── templates/
│   └── index.html
└── README.md
\`\`\`

---

### Step 2: Establish a Virtual Environment (Recommended)
This keeps your global python context clear of conflicts:

**For macOS / Linux:**
\`\`\`bash
python3 -m venv venv
source venv/bin/activate
\`\`\`

**For Windows (Command Prompt):**
\`\`\`cmd
python -m venv venv
venv\\Scripts\\activate
\`\`\`

**For Windows (PowerShell):**
\`\`\`powershell
python -m venv venv
.\\venv\\Scripts\\Activate.ps1
\`\`\`

---

### Step 3: Install Required Dependencies
Download Google's official GenAI SDK and Flask with one command:
\`\`\`bash
pip install -r requirements.txt
\`\`\`

---

### Step 4: Configure the Gemini API Key Environment
1. Copy the \`.env.example\` file and rename it to a active \`.env\` file:
   \`\`\`bash
   cp .env.example .env
   \`\`\`
2. Open \`.env\` in your choice of editor and insert your safe Google Gemini key:
   \`\`\`env
   GEMINI_API_KEY="AIzaSyYourOwnActualFreeKeyHereFromAiStudio"
   \`\`\`

> *No API Key? Claim yours instantly for free by logging into [Google AI Studio](https://aistudio.google.com/)*.

---

### Step 5: Boot Up python server sandbox
Run the server to activate NLP handlers:
\`\`\`bash
python app.py
\`\`\`

Open your favorite browser and navigate to:
🔗 **[http://127.0.0.1:5000](http://127.0.0.1:5000)**

---

## 🎨 Visual Features & Customizations

1. **System Personality Prompting**: Change instructions in the left sidebar to dictate how the AI operates (e.g. "Answer like a poetic pirate", "Explain simply with analogies").
2. **Creativity Temperature Slider**: Tweak temperatures from \`0.0\` (exact, logical, code assistant) up to \`1.0\` (innovative, narrative, storyteller).
3. **Responsive Mobile-Friendly Layout**: Seamless fluid breakpoints powered by modern CSS rendering on notebooks, mobiles, or tablet panels.
`
  }
];
